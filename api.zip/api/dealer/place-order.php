<?php
/**
 * PLACE ORDER API (Dealer App — Manual Coupon Selection)
 * 
 * POST /api/dealer/place-order.php
 * Body: { 
 *   dealer_id,
 *   customer_id,
 *   items: [...],
 *   delivery_type,
 *   delivery_address (optional),
 *   notes (optional),
 *   coupon_id (optional)   // 0 = koi coupon nahi, >0 = specific coupon
 * }
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require '../config.php';
require '../db.php';

$input           = getInput();
$dealerId        = (int)($input['dealer_id'] ?? 0);
$customerId      = (int)($input['customer_id'] ?? 0);
$couponId        = (int)($input['coupon_id'] ?? 0);
$deliveryType    = trim($input['delivery_type'] ?? 'pickup');
$deliveryAddress = trim($input['delivery_address'] ?? '');
$notes           = trim($input['notes'] ?? '');
$items           = $input['items'] ?? [];

// ─── Validation ───
if ($dealerId <= 0) {
    jsonResponse(['status'=>'error','message'=>'dealer_id required']);
}
if ($customerId <= 0) {
    jsonResponse(['status'=>'error','message'=>'customer_id required']);
}
if (empty($items) || !is_array($items)) {
    jsonResponse(['status'=>'error','message'=>'items required (array)']);
}
if (!in_array($deliveryType, ['pickup', 'delivery'])) {
    jsonResponse(['status'=>'error','message'=>'Invalid delivery_type']);
}
if ($deliveryType === 'delivery' && empty($deliveryAddress)) {
    jsonResponse(['status'=>'error','message'=>'delivery_address required']);
}

$ip = getClientIp();

// ─── Dealer Check ───
$stmt = $db->prepare("SELECT id, name, station_name FROM dealers WHERE id = ? AND status = 'active' LIMIT 1");
$stmt->bind_param("i", $dealerId);
$stmt->execute();
$dealer = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$dealer) {
    jsonResponse(['status'=>'error','message'=>'Dealer not found or inactive']);
}

// ─── Customer Check ───
$stmt = $db->prepare("
    SELECT id, player_key, player_id, name, mobile, 
           total_coupons, remaining_coupons, used_coupons 
    FROM customers 
    WHERE id = ? LIMIT 1
");
$stmt->bind_param("i", $customerId);
$stmt->execute();
$customer = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$customer) {
    jsonResponse(['status'=>'error','message'=>'Customer not found']);
}

$key      = $customer['player_key'];
$playerId = $customer['player_id'];

// ─── Order items validate ───
$validatedItems = [];
$subtotal       = 0;

foreach ($items as $item) {
    $productId = (int)($item['product_id'] ?? 0);
    $quantity  = (int)($item['quantity'] ?? 0);

    if ($productId <= 0 || $quantity <= 0) {
        jsonResponse(['status'=>'error','message'=>'Invalid product_id or quantity']);
    }

    $stmt = $db->prepare("
        SELECT id, sku, name, brand, price, discount_percent, stock, status 
        FROM lube_products 
        WHERE id = ? LIMIT 1
    ");
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$product) {
        jsonResponse(['status'=>'error','message'=>"Product ID $productId not found"]);
    }
    if ($product['status'] !== 'active') {
        jsonResponse(['status'=>'error','message'=>"Product '{$product['name']}' is not available"]);
    }
    if ($product['stock'] < $quantity) {
        jsonResponse(['status'=>'error','message'=>"Not enough stock for '{$product['name']}'. Available: {$product['stock']}"]);
    }

    $price           = (float)$product['price'];
    $discountPercent = (float)$product['discount_percent'];
    $itemSubtotal    = $price * $quantity;

    if ($discountPercent > 0) {
        $itemSubtotal = $itemSubtotal - ($itemSubtotal * $discountPercent / 100);
    }

    $subtotal += $itemSubtotal;

    $validatedItems[] = [
        'product_id'       => $product['id'],
        'product_sku'      => $product['sku'] ?? '',
        'product_name'     => $product['name'],
        'product_brand'    => $product['brand'] ?? '',
        'quantity'         => $quantity,
        'price'            => $price,
        'discount_percent' => $discountPercent,
        'subtotal'         => round($itemSubtotal, 2),
    ];
}

// ─── Coupon Apply (Sirf Tab Jab App se coupon_id Aaya Ho) ───
$discount        = 0;
$appliedCouponId = null;
$appliedCode     = null;

if ($couponId > 0) {
    // ✅ Customer ke coupons mein se dhoondein
    $stmt = $db->prepare("
        SELECT * FROM coupons 
        WHERE id = ? 
          AND customer_id = ? 
          AND status = 'available' 
          AND min_purchase <= ?
        LIMIT 1
    ");
    $stmt->bind_param("iid", $couponId, $customerId, $subtotal);
    $stmt->execute();
    $coupon = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if (!$coupon) {
        jsonResponse([
            'status'  => 'error',
            'message' => 'Invalid coupon or coupon not available for this order'
        ]);
    }
    
    // Expiry check
    if (!empty($coupon['valid_to']) && strtotime($coupon['valid_to']) < time()) {
        jsonResponse(['status'=>'error','message'=>'Coupon has expired']);
    }
    
    // Discount calculate
    if ($coupon['discount_percent'] > 0) {
        $discount = ($subtotal * $coupon['discount_percent']) / 100;
    } elseif ($coupon['discount_amount'] > 0) {
        $discount = $coupon['discount_amount'];
    }
    
    $appliedCouponId = $coupon['id'];
    $appliedCode     = $coupon['title'];   // ✅ 'title' use kiya
}

$totalAmount = $subtotal - $discount;
$orderNumber = 'ORD' . date('Ymd') . strtoupper(substr(md5(uniqid()), 0, 6));

$db->begin_transaction();

try {
    // 1. Order insert
    $stmt = $db->prepare("
        INSERT INTO orders 
        (order_number, customer_id, dealer_id, player_key, player_id, 
         subtotal, discount, total_amount, 
         coupon_id, coupon_code, 
         status, payment_status, 
         delivery_type, delivery_address, notes, 
         created_at, updated_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'successful', 'paid', ?, ?, ?, NOW(), NOW())
    ");
    $stmt->bind_param("siisidddissss", 
        $orderNumber, $customerId, $dealerId, $key, $playerId, 
        $subtotal, $discount, $totalAmount, 
        $appliedCouponId, $appliedCode, 
        $deliveryType, $deliveryAddress, $notes
    );
    $stmt->execute();
    $orderId = $stmt->insert_id;
    $stmt->close();

    // 2. Order items insert
    foreach ($validatedItems as $vi) {
        $stmt = $db->prepare("
            INSERT INTO order_items 
            (order_id, product_id, product_sku, product_name, product_brand, 
             coupon_id, quantity, price, discount_percent, subtotal, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->bind_param("iisssiiddd", 
            $orderId, $vi['product_id'], $vi['product_sku'], $vi['product_name'], $vi['product_brand'], 
            $appliedCouponId, 
            $vi['quantity'], $vi['price'], $vi['discount_percent'], $vi['subtotal']
        );
        $stmt->execute();
        $stmt->close();

        // 3. Stock kam
        $stmt = $db->prepare("UPDATE lube_products SET stock = stock - ? WHERE id = ?");
        $stmt->bind_param("ii", $vi['quantity'], $vi['product_id']);
        $stmt->execute();
        $stmt->close();
    }

    // 4. Coupon used mark + Customers counts update (agar coupon laga)
    if ($appliedCouponId) {
        $stmt = $db->prepare("
            UPDATE coupons 
            SET status = 'used', 
                used_at = NOW(), 
                used_at_station = ? 
            WHERE id = ?
        ");
        $stmt->bind_param("si", $dealer['station_name'], $appliedCouponId);
        $stmt->execute();
        $stmt->close();
        
        $stmt = $db->prepare("
            UPDATE customers 
            SET remaining_coupons = remaining_coupons - 1, 
                used_coupons = used_coupons + 1 
            WHERE id = ?
        ");
        $stmt->bind_param("i", $customerId);
        $stmt->execute();
        $stmt->close();
    }

    // 5. Transaction insert
    $transactionRef = 'TXN' . strtoupper(substr(md5(uniqid()), 0, 10));
    $stationName    = $dealer['station_name'];
    
    $stmt = $db->prepare("
        INSERT INTO transactions 
        (customer_id, dealer_id, player_key, player_id, station_name, 
         amount, discount, final_amount, 
         coupon_id, coupon_code, status, transaction_ref, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'successful', ?, NOW())
    ");
    $stmt->bind_param("iisssdddsss", 
        $customerId, $dealerId, $key, $playerId, $stationName, 
        $subtotal, $discount, $totalAmount, 
        $appliedCouponId, $appliedCode, $transactionRef
    );
    $stmt->execute();
    $stmt->close();

    $db->commit();

    // ─── Success Response ───
    jsonResponse([
        'status'  => 'success',
        'message' => 'Order placed successfully',
        'order'   => [
            'id'                => (int)$orderId,
            'order_number'      => $orderNumber,
            'dealer_id'         => (int)$dealerId,
            'dealer_name'       => $dealer['name'],
            'station_name'      => $dealer['station_name'],
            'customer_id'       => (int)$customerId,
            'customer_name'     => $customer['name'],
            'customer_mobile'   => $customer['mobile'],
            'subtotal'          => round($subtotal, 2),
            'discount'          => round($discount, 2),
            'total_amount'      => round($totalAmount, 2),
            'coupon_applied'    => $appliedCode,
            'coupon_used'       => ($appliedCouponId ? true : false),
            'remaining_coupons' => (int)$customer['remaining_coupons'] - ($appliedCouponId ? 1 : 0),
            'status'            => 'successful',
            'payment_status'    => 'paid',
            'delivery_type'     => $deliveryType,
            'delivery_address'  => $deliveryAddress,
            'items'             => $validatedItems,
            'created_at'        => date('Y-m-d H:i:s'),
        ],
    ]);

} catch (Exception $e) {
    $db->rollback();
    jsonResponse(['status'=>'error','message'=>'Order failed: ' . $e->getMessage()]);
}