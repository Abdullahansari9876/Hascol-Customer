<?php
/**
 * REGISTER + OTP + IMEI + MOBILE + PASSWORD + 3 COUPONS + COUPON_NO + SKIP OTP
 * 
 * POST /api/register.php
 * Body: { 
 *   name, player_id, imei, mobile, password, 
 *   coupon_no (optional),
 *   skip_otp (optional)  // 0 = OTP chahiye, 1 = OTP skip
 * }
 * 
 * Customer register hota hai + 3 coupons milte hain (hamesha).
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require 'config.php';
require 'db.php';

$input    = getInput();
$name     = trim($input['name'] ?? '');
$playerId = trim($input['player_id'] ?? '');
$email    = trim($input['email'] ?? '');
$imei     = trim($input['imei'] ?? '');
$mobile   = trim($input['mobile'] ?? '');
$password = trim($input['password'] ?? '');
$userCouponNo = trim($input['coupon_no'] ?? '');
$skipOtp      = (int)($input['skip_otp'] ?? 0);

// ─── Validation ───
if (empty($name))     jsonResponse(['status'=>'error','message'=>'name required']);
if (empty($playerId)) jsonResponse(['status'=>'error','message'=>'player_id required']);
if (empty($imei))     jsonResponse(['status'=>'error','message'=>'imei required']);
if (empty($mobile))   jsonResponse(['status'=>'error','message'=>'mobile required']);
if (empty($password)) jsonResponse(['status'=>'error','message'=>'password required']);

if (!preg_match('/^(03[0-9]{9}|\+923[0-9]{9})$/', $mobile)) {
    jsonResponse(['status'=>'error','message'=>'Invalid mobile number (e.g., 03001234567)']);
}

if (strlen($password) < 6) {
    jsonResponse(['status'=>'error','message'=>'Password must be at least 6 characters']);
}

if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    jsonResponse(['status'=>'error','message'=>'Invalid email format']);
}

// ─── Coupon_no validation ───
if (!empty($userCouponNo)) {
    if (strlen($userCouponNo) < 4) {
        jsonResponse(['status'=>'error','message'=>'Coupon number must be at least 4 characters']);
    }
    if (!preg_match('/^[a-zA-Z0-9_\-]+$/', $userCouponNo)) {
        jsonResponse(['status'=>'error','message'=>'Coupon number can only contain letters, numbers, hyphen, and underscore']);
    }
}

$key = playerKey($playerId);
$ip  = getClientIp();
$passwordHash = password_hash($password, PASSWORD_BCRYPT);

// ─── Mobile already registered check ───
$stmt = $db->prepare("SELECT id, player_key FROM customers WHERE mobile = ?");
$stmt->bind_param("s", $mobile);
$stmt->execute();
$mobileExists = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($mobileExists && $mobileExists['player_key'] !== $key) {
    jsonResponse(['status'=>'error','message'=>'Mobile number already registered']);
}

// ─── Check existing customer ───
$stmt = $db->prepare("SELECT * FROM customers WHERE player_key = ?");
$stmt->bind_param("s", $key);
$stmt->execute();
$existing = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($existing && $existing['verified'] == 1) {
    jsonResponse([
        'status'    => 'exists',
        'message'   => 'Player already registered',
        'player_id' => $playerId,
    ]);
}

// ═══════════════════════════════════════════════════
// ✅ Coupon No Logic
// ═══════════════════════════════════════════════════

function generateCouponNo() {
    $random = strtoupper(substr(md5(uniqid(microtime(), true)), 0, 8));
    return 'CUST-' . $random;
}

if (!empty($userCouponNo)) {
    $stmt = $db->prepare("SELECT id, name, mobile FROM customers WHERE coupon_no = ? LIMIT 1");
    $stmt->bind_param("s", $userCouponNo);
    $stmt->execute();
    $couponExists = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($couponExists) {
        jsonResponse([
            'status'  => 'exists',
            'message' => 'This coupon number is already registered with another customer',
            'coupon_no' => $userCouponNo,
        ]);
    }
    
    $couponNo = $userCouponNo;
    $couponSource = 'user_provided';
    
} else {
    $couponNo   = generateCouponNo();
    $maxTries   = 5;
    $tries      = 0;
    
    while ($tries < $maxTries) {
        $stmt = $db->prepare("SELECT id FROM customers WHERE coupon_no = ? LIMIT 1");
        $stmt->bind_param("s", $couponNo);
        $stmt->execute();
        $exists = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if (!$exists) break;
        
        $couponNo = generateCouponNo();
        $tries++;
    }
    
    if ($tries >= $maxTries) {
        jsonResponse(['status'=>'error','message'=>'Could not generate unique coupon_no. Please try again.']);
    }
    
    $couponSource = 'auto_generated';
}

// ═══════════════════════════════════════════════════

// ─── Customer save/update ───
$verifiedStatus = ($skipOtp === 1) ? 1 : 0;
$verifiedAt     = ($skipOtp === 1) ? date('Y-m-d H:i:s') : null;

$stmt = $db->prepare("
    INSERT INTO customers 
    (player_key, player_id, name, email, mobile, password, imei, coupon_no, verified, verified_at, status, ip_address, created_at, updated_at) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, NOW(), NOW())
    ON DUPLICATE KEY UPDATE
        name = VALUES(name),
        email = VALUES(email),
        mobile = VALUES(mobile),
        password = VALUES(password),
        imei = VALUES(imei),
        coupon_no = VALUES(coupon_no),
        verified = VALUES(verified),
        verified_at = VALUES(verified_at),
        ip_address = VALUES(ip_address),
        updated_at = NOW()
");
$stmt->bind_param("ssssssssiss", 
    $key, $playerId, $name, $email, $mobile, $passwordHash, $imei, $couponNo, 
    $verifiedStatus, $verifiedAt, $ip
);
if (!$stmt->execute()) {
    jsonResponse(['status'=>'error','message'=>'Customer save failed: ' . $stmt->error]);
}
$stmt->close();

// ═══════════════════════════════════════════════════
// ✅ 3 Default Coupons Insert Karein (Har Case Mein)
// ═══════════════════════════════════════════════════

$stmt = $db->prepare("SELECT id FROM customers WHERE player_key = ? LIMIT 1");
$stmt->bind_param("s", $key);
$stmt->execute();
$customerRow = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$customerRow) {
    jsonResponse(['status'=>'error','message'=>'Customer not found after insert']);
}

$customerId = $customerRow['id'];

// Check: pehle se coupons hain?
$stmt = $db->prepare("SELECT COUNT(*) as cnt FROM coupons WHERE customer_id = ?");
$stmt->bind_param("i", $customerId);
$stmt->execute();
$couponCount = $stmt->get_result()->fetch_assoc()['cnt'];
$stmt->close();

// Agar coupons nahi hain, to 3 default coupons insert karein
if ($couponCount == 0) {
    $defaultCoupons = [
        ['title' => 'Welcome 10% Off', 'desc' => 'Get 10% discount on your first purchase', 'percent' => 10.00, 'amount' => 0.00, 'min' => 500.00],
        ['title' => 'Engine Oil 5% Off', 'desc' => 'Get 5% discount on engine oil', 'percent' => 5.00, 'amount' => 0.00, 'min' => 1000.00],
        ['title' => 'Fuel 3% Off', 'desc' => 'Get 3% discount on fuel', 'percent' => 3.00, 'amount' => 0.00, 'min' => 500.00],
    ];
    
    $validFrom = date('Y-m-d H:i:s');
    $validTo   = date('Y-m-d H:i:s', time() + 30 * 24 * 3600);
    
    foreach ($defaultCoupons as $c) {
        $stmt = $db->prepare("
            INSERT INTO coupons 
            (customer_id, title, description, 
             discount_percent, discount_amount, min_purchase, 
             valid_from, valid_to, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'available')
        ");
        $stmt->bind_param("issddsss", 
            $customerId, $c['title'], $c['desc'], 
            $c['percent'], $c['amount'], $c['min'], $validFrom, $validTo
        );
        if (!$stmt->execute()) {
            error_log("Coupon insert failed: " . $stmt->error);
            jsonResponse(['status'=>'error','message'=>'Coupon insert failed: ' . $stmt->error]);
        }
        $stmt->close();
    }
}

// ✅ Counts ALWAYS update karein (coupons table se)
$stmt = $db->prepare("
    UPDATE customers 
    SET total_coupons = (SELECT COUNT(*) FROM coupons WHERE customer_id = ?),
        remaining_coupons = (SELECT COUNT(*) FROM coupons WHERE customer_id = ? AND status = 'available'),
        used_coupons = (SELECT COUNT(*) FROM coupons WHERE customer_id = ? AND status = 'used')
    WHERE id = ?
");
$stmt->bind_param("iiii", $customerId, $customerId, $customerId, $customerId);
if (!$stmt->execute()) {
    error_log("Customer counts update failed: " . $stmt->error);
    jsonResponse(['status'=>'error','message'=>'Counts update failed: ' . $stmt->error]);
}
$stmt->close();

// ✅ Inserted count lein (response ke liye)
$stmt = $db->prepare("SELECT COUNT(*) as cnt FROM coupons WHERE customer_id = ?");
$stmt->bind_param("i", $customerId);
$stmt->execute();
$insertedCount = (int)$stmt->get_result()->fetch_assoc()['cnt'];
$stmt->close();
// ═══════════════════════════════════════════════════

// ─── Firebase Customer (backup) ───
fbSet("customers/$key", [
    'player_id'  => $playerId,
    'name'       => $name,
    'email'      => $email,
    'mobile'     => $mobile,
    'imei'       => $imei,
    'coupon_no'  => $couponNo,
    'verified'   => ($verifiedStatus === 1),
    'created_at' => $existing['created_at'] ?? date('Y-m-d H:i:s'),
    'updated_at' => date('Y-m-d H:i:s'),
]);

// ═══════════════════════════════════════════════════
// ✅ SKIP OTP LOGIC
// ═══════════════════════════════════════════════════

if ($skipOtp === 1) {
    $token = bin2hex(random_bytes(32));
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    $stmt = $db->prepare("
        INSERT INTO sessions 
        (token, player_key, player_id, ip_address, user_agent, created_at, expires_at, is_active) 
        VALUES (?, ?, ?, ?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY), 1)
    ");
    $stmt->bind_param("sssss", $token, $key, $playerId, $ip, $userAgent);
    $stmt->execute();
    $stmt->close();
    
    fbSet("sessions/$token", [
        'player_id' => $playerId,
        'player_key'=> $key,
        'created_at'=> date('Y-m-d H:i:s'),
        'expires_at'=> date('Y-m-d H:i:s', time() + 30*24*3600),
    ]);
    
    jsonResponse([
        'status'         => 'success',
        'message'        => 'Registration complete (OTP skipped)',
        'player_id'      => $playerId,
        'mobile'         => $mobile,
        'imei'           => $imei,
        'coupon_no'      => $couponNo,
        'coupon_source'  => $couponSource,
        'total_coupons'  => $insertedCount,
        'otp_skipped'    => true,
        'token'          => $token,
        'verified'       => true,
    ]);
}

// ═══════════════════════════════════════════════════
// ✅ NORMAL OTP FLOW (skip_otp = 0)
// ═══════════════════════════════════════════════════

$otp         = str_pad(rand(0, pow(10, OTP_LENGTH) - 1), OTP_LENGTH, '0', STR_PAD_LEFT);
$now         = time();
$expires     = $now + OTP_EXPIRY;
$maxAttempts = OTP_MAX_ATTEMPTS;

$stmt = $db->prepare("
    INSERT INTO otps 
    (player_key, player_id, otp, type, attempts, max_attempts, is_used, sent_at, expires_at, ip_address) 
    VALUES (?, ?, ?, 'register', 0, ?, 0, NOW(), FROM_UNIXTIME(?), ?)
");
$stmt->bind_param("sssiis", $key, $playerId, $otp, $maxAttempts, $expires, $ip);
if (!$stmt->execute()) {
    jsonResponse(['status'=>'error','message'=>'OTP insert failed: ' . $stmt->error]);
}
$stmt->close();

$stmt = $db->prepare("INSERT INTO otp_logs (player_key, action, otp, ip_address, note, created_at) VALUES (?, 'sent', ?, ?, 'OTP sent for registration', NOW())");
$stmt->bind_param("sss", $key, $otp, $ip);
$stmt->execute();
$stmt->close();

$notificationMessage = "Your OTP is: $otp\nValid for 10 minutes.";
$payload = json_encode(['otp' => $otp, 'expires_at' => date('Y-m-d H:i:s', $expires)]);

$stmt = $db->prepare("
    INSERT INTO notifications 
    (player_key, player_id, type, title, message, payload, is_read, created_at) 
    VALUES (?, ?, 'otp', '🔐 Verification Code', ?, ?, 0, NOW())
");
$stmt->bind_param("ssss", $key, $playerId, $notificationMessage, $payload);
$stmt->execute();
$stmt->close();

fbSet("otps/$key", [
    'otp'        => $otp,
    'player_id'  => $playerId,
    'name'       => $name,
    'imei'       => $imei,
    'type'       => 'register_otp',
    'title'      => '🔐 Verification Code',
    'message'    => "Your OTP is: $otp\nValid for 10 minutes.",
    'is_read'    => false,
    'sent_at'    => date('Y-m-d H:i:s', $now),
    'expires_at' => date('Y-m-d H:i:s', $expires),
    'expires_ts' => $expires,
    'attempts'   => 0,
]);

jsonResponse([
    'status'         => 'success',
    'message'        => 'OTP sent. Valid for 10 minutes.',
    'player_id'      => $playerId,
    'mobile'         => $mobile,
    'imei'           => $imei,
    'coupon_no'      => $couponNo,
    'coupon_source'  => $couponSource,
    'total_coupons'  => $insertedCount,
    'otp_skipped'    => false,
    'otp'            => $otp,
    'expires_in'     => OTP_EXPIRY,
    'expires_at'     => date('Y-m-d H:i:s', $expires),
]);