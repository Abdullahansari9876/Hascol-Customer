<?php
/**
 * UPDATE PROFILE API (Without Token)
 * 
 * POST /api/update-profile.php
 * Body: { 
 *   customer_id,
 *   name (optional),
 *   email (optional),
 *   profile_image (optional)
 * }
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require '../config.php';
require '../db.php';

$input        = getInput();
$customerId   = (int)($input['customer_id'] ?? 0);
$name         = trim($input['name'] ?? '');
$email        = trim($input['email'] ?? '');
$profileImage = trim($input['profile_image'] ?? '');

// ─── Validation ───
if ($customerId <= 0) {
    jsonResponse(['status'=>'error','message'=>'customer_id required']);
}

// ─── Customer check ───
$stmt = $db->prepare("SELECT id, name FROM customers WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $customerId);
$stmt->execute();
$customerCheck = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$customerCheck) {
    jsonResponse(['status'=>'error','message'=>'Customer not found']);
}

// ─── Email validation (agar diya gaya) ───
if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    jsonResponse(['status'=>'error','message'=>'Invalid email format']);
}

// ─── Kam se kam ek field zaroori ───
if (empty($name) && empty($email) && empty($profileImage)) {
    jsonResponse(['status'=>'error','message'=>'At least one field (name, email, or profile_image) required']);
}

// ─── Update query build karein ───
$updates = [];
$params  = [];
$types   = "";

if (!empty($name)) {
    $updates[] = "name = ?";
    $params[]  = $name;
    $types    .= "s";
}

if (!empty($email)) {
    $updates[] = "email = ?";
    $params[]  = $email;
    $types    .= "s";
}

if (!empty($profileImage)) {
    $updates[] = "profile_image = ?";
    $params[]  = $profileImage;
    $types    .= "s";
}

$updates[] = "updated_at = NOW()";
$params[]  = $customerId;
$types    .= "i";

$sql = "UPDATE customers SET " . implode(", ", $updates) . " WHERE id = ?";

$stmt = $db->prepare($sql);
$stmt->bind_param($types, ...$params);

if (!$stmt->execute()) {
    jsonResponse(['status'=>'error','message'=>'Profile update failed: ' . $stmt->error]);
}
$stmt->close();

// ─── Updated data wapas bhejein ───
$stmt = $db->prepare("
    SELECT id, player_id, name, email, profile_image, mobile, imei, 
           verified, status, total_coupons, remaining_coupons, used_coupons,
           created_at, verified_at, last_login 
    FROM customers 
    WHERE id = ? LIMIT 1
");
$stmt->bind_param("i", $customerId);
$stmt->execute();
$customer = $stmt->get_result()->fetch_assoc();
$stmt->close();

jsonResponse([
    'status'  => 'success',
    'message' => 'Profile updated successfully',
    'profile' => [
        'id'                => (int)$customer['id'],
        'player_id'         => $customer['player_id'],
        'name'              => $customer['name'],
        'email'             => $customer['email'] ?? '',
        'profile_image'     => $customer['profile_image'] ?? '',
        'mobile'            => $customer['mobile'] ?? '',
        'imei'              => $customer['imei'] ?? '',
        'verified'          => (bool)$customer['verified'],
        'status'            => $customer['status'],
        'total_coupons'     => (int)$customer['total_coupons'],
        'remaining_coupons' => (int)$customer['remaining_coupons'],
        'used_coupons'      => (int)$customer['used_coupons'],
        'member_since'      => date('d M Y', strtotime($customer['created_at'])),
        'verified_at'       => $customer['verified_at'],
        'last_login'        => $customer['last_login'],
    ],
]);