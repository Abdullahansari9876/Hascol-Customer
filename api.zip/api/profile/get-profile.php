<?php
/**
 * MY PROFILE API (Without Token)
 * 
 * POST /api/profile.php
 * Body: { customer_id }
 * 
 * Customer ki profile return karta hai (profile_image ke saath).
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require '../config.php';
require '../db.php';

$input      = getInput();
$customerId = (int)($input['customer_id'] ?? 0);

// ─── Validation ───
if ($customerId <= 0) {
    jsonResponse(['status'=>'error','message'=>'customer_id required']);
}

// ─── Customer detail ───
$stmt = $db->prepare("
    SELECT id, player_id, name, email, profile_image, mobile, imei, 
           verified, status,
           total_coupons, remaining_coupons, used_coupons,
           created_at, verified_at, last_login
    FROM customers 
    WHERE id = ? LIMIT 1
");
$stmt->bind_param("i", $customerId);
$stmt->execute();
$customer = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$customer) {
    jsonResponse(['status'=>'error','message'=>'Customer not found']);
}

jsonResponse([
    'status'  => 'success',
    'message' => 'Profile fetched successfully',
    'profile' => [
        'id'                => (int)$customer['id'],
        'player_id'         => $customer['player_id'],
        'name'              => $customer['name'],
        'email'             => $customer['email'] ?? '',
        'profile_image'     => $customer['profile_image'] ?? '',   // ✅ Naya
        'mobile'            => $customer['mobile'] ?? '',
        'imei'              => $customer['imei'] ?? '',
        'verified'          => (bool)$customer['verified'],
        'status'            => $customer['status'],
        'total_coupons'     => (int)$customer['total_coupons'],
        'remaining_coupons' => (int)$customer['remaining_coupons'],
        'used_coupons'      => (int)$customer['used_coupons'],
        'member_since'      => date('d M Y', strtotime($customer['created_at'])),
        'verified_at'       => $customer['verified_at'],
        'last_login'        => $customer['last_login'],
    ],
]);